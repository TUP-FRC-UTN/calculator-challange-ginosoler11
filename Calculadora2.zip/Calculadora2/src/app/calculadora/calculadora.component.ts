import { Component, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-calculadora',
  templateUrl: './calculadora.component.html',
  styleUrls: ['./calculadora.component.css']
})
export class CalculadoraComponent {
  @Input() num1: number = 0;
  @Input() num2: number = 0;

  @Output() result = new EventEmitter<number>();

  sumar() {
    this.result.emit(this.num1 + this.num2);
  }

  restar() {
    this.result.emit(this.num1 - this.num2);
  }

  multiplicar() {
    this.result.emit(this.num1 * this.num2);
  }

  dividir() {
    if (this.num2 !== 0) {
      this.result.emit(this.num1 / this.num2);
    } else {
      alert('No se puede dividir por 0');
    }
  }

  potencia() {
    this.result.emit(Math.pow(this.num1, this.num2));
  }

  raiz() {
    this.result.emit(Math.sqrt(this.num1));
  }
}
