import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'calculadora';
  num1: number = 0;
  num2: number = 0;
  resultado: number | null = null;

  manejarResultado(resultado: any) {
    this.resultado = resultado;
  }
}
